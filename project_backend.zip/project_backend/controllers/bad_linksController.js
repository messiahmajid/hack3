const BadLink = require('../models/bad_links');
const searchUris = require('../repos/webrisk');
const UrlAnalyzer = require('../repos/url_analysis');

exports.validateUrl = async (req, res) => {
    try {
        const userId = 1;
        if (!userId) {
            return res.status(401).json({ success: false, message: "Not logged in" });
        }

        const urls = req.body.urls;
        if (!Array.isArray(urls) || urls.length === 0) {
            return res.status(400).json({ success: false, message: "Expected an array of URL objects." });
        }

        // Extract the list of URLs from the request.
        const currentUrls = urls.map(urlObj => urlObj.url);
        let highRiskUrls = [];

        // Step 1: Query the WebRisk API for each URL.
        const webRiskResults = await searchUris(urls);
        const webRiskHighRisk = webRiskResults.filter(urlObj => urlObj.risk === "High");

        if (webRiskHighRisk.length > 0) {
            highRiskUrls.push(...webRiskHighRisk);

            // ✅ Add/update all high-risk URLs in the BadLink table
            for (const highRisk of webRiskHighRisk) {
                const existingEntry = await BadLink.findOne({
                    "badLinks": { $elemMatch: { userId, url: highRisk.url, risk: "High" } }
                });

                if (existingEntry) {
                    await BadLink.updateOne(
                        { "badLinks": { $elemMatch: { userId, url: highRisk.url, risk: "High" } } },
                        { $inc: { "badLinks.$.frequency": 1 } }
                    );
                } else {
                    await BadLink.updateOne(
                        {},
                        { $push: { badLinks: { url: highRisk.url, risk: "High", frequency: 1, userId } } },
                        { upsert: true }
                    );
                }
            }
        }

        // Step 2: Check the BadLink table for any high-risk URLs
        const badLinkDoc = await BadLink.findOne({
            "badLinks": { $elemMatch: { userId, risk: "High", url: { $in: currentUrls } } }
        });

        if (badLinkDoc) {
            const highRiskFromDB = badLinkDoc.badLinks.filter(entry =>
                entry.userId === userId && entry.risk === "High" && currentUrls.includes(entry.url)
            );

            if (highRiskFromDB.length > 0) {
                highRiskUrls.push(...highRiskFromDB);
            }
        }

        // Step 3: No high-risk URLs yet? Call the LLM-based URL analysis.
        if (highRiskUrls.length === 0) {
            const analyzer = new UrlAnalyzer();
            const llmResults = await analyzer.analyzeURLs(urls);
            const highRiskLLM = Array.isArray(llmResults)
                ? llmResults.filter(item => item.risk_classification === "High")
                : [];

            if (highRiskLLM.length > 0) {
                highRiskUrls.push(...highRiskLLM);

                // ✅ Record high-risk URLs from the LLM analysis in the DB
                for (const highRisk of highRiskLLM) {
                    const existingEntryLLM = await BadLink.findOne({
                        "badLinks": { $elemMatch: { userId, url: highRisk.url, risk: "High" } }
                    });

                    if (existingEntryLLM) {
                        await BadLink.updateOne(
                            { "badLinks": { $elemMatch: { userId, url: highRisk.url, risk: "High" } } },
                            { $inc: { "badLinks.$.frequency": 1 } }
                        );
                    } else {
                        await BadLink.updateOne(
                            {},
                            { $push: { badLinks: { url: highRisk.url, risk: "High", frequency: 1, userId } } },
                            { upsert: true }
                        );
                    }
                }
            }
        }

        // ✅ Return all high-risk URLs found
        return res.status(200).json({ success: true, highRiskUrls: highRiskUrls });

    } catch (error) {
        console.error("❌ Error in validateUrl:", error);
        return res.status(500).json({ success: false, message: "Internal Server Error: " + error.message });
    }
};
