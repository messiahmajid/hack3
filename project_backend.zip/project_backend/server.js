const express = require('express');
const cors = require('cors');
const session = require('express-session');  // ✅ Import express-session
const mongoose = require('mongoose');
const { connectDB } = require('./config/db');
const authRouter = require('./routes/auth');
const searchUri = require('./repos/webrisk');
const { isLoggedIn } = require('./middleware/auth');
const path = require('path');
const MessageAnalyzer = require('./repos/image_analysis');
const SentimentAnalyzer = require('./repos/sentiment_analysis');
const UrlAnalyzer = require('./repos/url_analysis');
const ScamMessageAnalyzer  = require('./repos/message_last_step')
const { scamClassifier } = require('./repos/decision_tree_classifier');
const urlRouter = require('./routes/bad_linksRouter');
const imageRouter = require('./routes/image_analysis_router');

const app = express();
const port = 3000;




const corsOptions = {
    origin: (origin, callback) => {
        const allowedOrigins = [
            'http://localhost:3001', // React Frontend
            'chrome-extension://iagcokkhpnffadlppbbnodjmkkoiijln', // Chrome Extension
            'https://x.com' ,
            "https://web.whatsapp.com",
            "https://mail.google.com",
            "https://www.instagram.com",
            "https://learn.microsoft.com"// ✅ Allow Twitter if needed
        ];

        if (!origin || allowedOrigins.includes(origin)) {
            return callback(null, true);
        }

        console.error(`❌ CORS BLOCKED ORIGIN: ${origin}`);
        return callback(new Error('Not allowed by CORS'));
    },
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true
};


// Middleware
app.use(express.json());
app.use(cors(corsOptions));

// ✅ Initialize express-session BEFORE routes
app.use(session({
    name: 'ScamSpot-session',
    secret: process.env.SECRET,
    maxAge: 31*24 * 60 * 60 * 1000, // 🔑 Use a strong, unique secret
    // Set to `true` only if using HTTPS
}));

// Database connection
const startServer = async () => {
    try {
        await connectDB();
        app.listen(port, () => {
            console.log(`🚀 Server running on port ${port}`);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

// ✅ Register routes after middleware
app.use('/auth', authRouter);

// Default route
app.get('', (req, res) => {
    res.send('Server is operational');
});

app.use("/",urlRouter)
app.use("/",imageRouter)

// Start the server
startServer();
